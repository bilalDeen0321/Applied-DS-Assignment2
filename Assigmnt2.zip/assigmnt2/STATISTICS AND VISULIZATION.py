#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns 


# In[2]:


data = pd.read_excel('climate-change-excel-4-6-mb-.xls')
data.head()


# In[3]:


data.shape


# In[4]:


data.columns


# In[5]:


data.describe()


# In[6]:


data=data.drop(['Country code','Series code',"SCALE","Decimals"],axis=1)


# In[7]:


data


# In[8]:


data.isnull().sum()


# In[9]:


#df = data.iloc[:,2:]


# In[10]:


#here there is a code to fill the empty data with mean 
#if i apply any method to fill the nulls it will effect the real data so i commented this code
""""df = df.where(df.applymap(
    lambda x: str(x).isdigit()
))

df = df.fillna(df.mean())"""


# # FOR ZAMBIA

# In[11]:


df_Zambia1=data[data['Country name'] == 'Zambia']
df_Zambia1.head()


# In[12]:


df_Zambia = df_Zambia1.iloc[:,1:] 


# In[13]:


df_Zambia = df_Zambia.T.iloc[:,1:]


# In[14]:


df_Zambia


# In[15]:


#first row as header
new_header = df_Zambia.iloc[0] 

df_Zambia = df_Zambia[1:] 

df_Zambia.columns = new_header

df_Zambia.head()


# In[16]:


df_Zambia.shape


# In[17]:


df_Zambia.describe()


# In[18]:


plt.figure(figsize=(15,9))
plt.plot(df_Zambia["Physicians (per 1,000 people)"], marker="^",color="g", linestyle="--")
plt.plot(df_Zambia["Urban population growth (annual %)"],  marker="^",color="r", linestyle="--")
plt.title("Physicians (per 1,000 people)") 
plt.xticks(rotation=90)
plt.show()


# In[19]:


plt.figure(figsize=(15,9))
plt.plot(df_Zambia["Malaria incidence rate (per 100,000 people)"], marker="^",color="k", linestyle="--")
plt.xticks(rotation=90)
plt.show()


# In[20]:


plt.figure(figsize=(15,9))
plt.plot(df_Zambia["Population growth (annual %)"], marker="o",color="r", linestyle="-")
plt.xticks(rotation=90)
plt.show()


# In[21]:


df_Zambia


# # corelation between Energy use per capita (kilograms of oil equivalent) and Population growth (annual %) for Zabia country

# In[71]:


df_Zambia['Energy use per capita (kilograms of oil equivalent)'] = df_Zambia['Energy use per capita (kilograms of oil equivalent)'].astype(int)

df_Zambia['Population growth (annual %)']=df_Zambia["Population growth (annual %)"].astype(int)

corelation = df_Zambia.loc[:,['Population growth (annual %)','Energy use per capita (kilograms of oil equivalent)']]
cor = corelation.corr()
sns.heatmap(cor,annot = True)


# # For AFGHANISTAN

# In[23]:


df_Afghanistan=data[data['Country name'] == 'Afghanistan']
df_Afghanistan.head()


# In[24]:


df_Afghanistan = df_Afghanistan.iloc[:,1:] 

df_Afghanistan = df_Afghanistan.T.iloc[:,1:] 

#first row as header
new_header = df_Afghanistan.iloc[0] 

df_Afghanistan = df_Afghanistan[1:] 

df_Afghanistan.columns = new_header

df_Afghanistan.head()


# In[25]:


df_Afghanistan.shape


# In[26]:


df_Afghanistan.describe()


# In[28]:


plt.figure(figsize=(15,9))
plt.plot(df_Afghanistan["Physicians (per 1,000 people)"], marker="^",color="g", linestyle="--",label="Physicians")
plt.plot(df_Afghanistan["Urban population growth (annual %)"],  marker="^",color="r", linestyle="--",label="Urban Populaton")
plt.xticks(rotation=90)
plt.legend(loc = 10)
plt.show()


# In[29]:


plt.figure(figsize=(15,9))
plt.plot(df_Afghanistan["Population growth (annual %)"], marker="o",color="b", linestyle="-")
plt.xticks(rotation=90)
plt.show()


# # corelation between Energy use per capita (kilograms of oil equivalent) and Population growth (annual %) for AFGHANISTAN country

# In[72]:


df_Afghanistan['Energy use per capita (kilograms of oil equivalent)'] = df_Afghanistan['Energy use per capita (kilograms of oil equivalent)'].astype(int)

df_Afghanistan['Population growth (annual %)']=df_Afghanistan["Population growth (annual %)"].astype(int)

corelation = df_Afghanistan.loc[:,['Population growth (annual %)','Energy use per capita (kilograms of oil equivalent)']]
cor = corelation.corr()
sns.heatmap(cor,annot = True)


# # For Angola

# In[30]:


df_Angola=data[data['Country name'] == 'Angola']
df_Angola.head()


# In[31]:


df_Angola = df_Angola.iloc[:,1:] 

df_Angola = df_Angola.T.iloc[:,1:] 

#first row as header
new_header = df_Angola.iloc[0] 

df_Angola = df_Angola[1:] 

df_Angola.columns = new_header

df_Angola.head()


# In[32]:


plt.figure(figsize=(15,9))
plt.plot(df_Angola["Physicians (per 1,000 people)"], marker="^",color="g", linestyle="--",label="Physicians")
plt.plot(df_Angola["Urban population growth (annual %)"],  marker="^",color="r", linestyle="--",label="Urban Populaton")
plt.xticks(rotation=90)
plt.legend(loc = 10)
plt.show()


# In[33]:


plt.figure(figsize=(15,9))
plt.plot(df_Angola["Population growth (annual %)"], marker="o",color="b", linestyle="-")
plt.xticks(rotation=90)
plt.show()


# # corelation between Energy use per capita (kilograms of oil equivalent) and Population growth (annual %) for ANGOLA country

# In[73]:


df_Angola['Energy use per capita (kilograms of oil equivalent)'] = df_Angola['Energy use per capita (kilograms of oil equivalent)'].astype(int)

df_Angola['Population growth (annual %)']=df_Angola["Population growth (annual %)"].astype(int)

corelation = df_Angola.loc[:,['Population growth (annual %)','Energy use per capita (kilograms of oil equivalent)']]
cor = corelation.corr()
sns.heatmap(cor,annot = True)


# # For South Africa

# In[34]:


df_SAF=data[data['Country name'] == 'South Africa']
df_SAF.head()


# In[35]:


df_SAF = df_SAF.iloc[:,1:] 

df_SAF = df_SAF.T.iloc[:,1:] 

#first row as header
new_header = df_SAF.iloc[0] 

df_SAF = df_SAF[1:] 

df_SAF.columns = new_header

df_SAF.head()


# In[36]:


df_SAF.describe()


# In[37]:


plt.figure(figsize=(15,9))
plt.plot(df_SAF["Physicians (per 1,000 people)"], marker="^",color="g", linestyle="--",label="Physicians")
plt.plot(df_SAF["Urban population growth (annual %)"],  marker="^",color="r", linestyle="--",label="Urban Populaton")
plt.xticks(rotation=90)
plt.legend(loc = 10)
plt.show()


# In[38]:


plt.figure(figsize=(15,9))
plt.plot(df_SAF["Population growth (annual %)"], marker="o",color="b", linestyle="-")
plt.xticks(rotation=90)
plt.show()


# # corelation between Energy use per capita (kilograms of oil equivalent) and Population growth (annual %) for SOUTH AFRICA country

# In[74]:


df_SAF['Energy use per capita (kilograms of oil equivalent)'] = df_SAF['Energy use per capita (kilograms of oil equivalent)'].astype(int)

df_SAF['Population growth (annual %)']=df_SAF["Population growth (annual %)"].astype(int)

corelation = df_SAF.loc[:,['Population growth (annual %)','Energy use per capita (kilograms of oil equivalent)']]
cor = corelation.corr()
sns.heatmap(cor,annot = True)


# # SUBPLOTS TO COMAPRE THE COUTRIES TREND ACCORDING TO TIME

# # WITH Physicians and urban population Growth

# In[45]:


plt.figure(figsize = (15,15))

plt.subplot(2,2,1)
plt.plot(df_Zambia["Physicians (per 1,000 people)"], marker="^",color="g", linestyle="--",label="Physicians")
plt.plot(df_Zambia["Urban population growth (annual %)"],  marker="^",color="r", linestyle="--",label="Urban Population")
plt.xticks(rotation=90)
plt.title("ZAMBIA") 
plt.xticks(rotation=90)

plt.subplot(2,2,2)
plt.plot(df_Afghanistan["Physicians (per 1,000 people)"], marker="^",color="g", linestyle="--",label="Physicians")
plt.plot(df_Afghanistan["Urban population growth (annual %)"],  marker="^",color="r", linestyle="--",label="Urban Populaton")
plt.xticks(rotation=90)
plt.title("AFGHANISTAN") 
plt.legend(loc = 10)

plt.subplot(2,2,3)
plt.plot(df_Angola["Physicians (per 1,000 people)"], marker="o",color="g", linestyle="--",label="Physicians")
plt.plot(df_Angola["Urban population growth (annual %)"],  marker="^",color="r", linestyle="--",label="Urban Populaton")
plt.xticks(rotation=90)
plt.title("ANGOLA") 
#plt.legend(loc = 10)


plt.subplot(2,2,4)
plt.plot(df_SAF["Physicians (per 1,000 people)"], marker="^",color="g", linestyle="--",label="Physicians")
plt.plot(df_SAF["Urban population growth (annual %)"],  marker="^",color="r", linestyle="--",label="Urban Populaton")
plt.xticks(rotation=90)
plt.title("SOUTH AFRICA") 
plt.legend(loc = 10)

plt.show()


# # Compare total population growth of different countries

# In[44]:


plt.figure(figsize = (15,15))

plt.subplot(2,2,1)
plt.plot(df_Zambia["Population growth (annual %)"], marker="o",color="r", linestyle="-")
plt.xticks(rotation=90)
plt.title("ZAMBIA")

plt.subplot(2,2,2)
plt.plot(df_Afghanistan["Population growth (annual %)"], marker="o",color="b", linestyle="-")
plt.xticks(rotation=90)
plt.title("AFGHANISTAN")

plt.subplot(2,2,3)
plt.plot(df_Angola["Population growth (annual %)"], marker="o",color="b", linestyle="-")
plt.xticks(rotation=90)
plt.title("ANGOLA")

plt.subplot(2,2,4)
plt.plot(df_SAF["Population growth (annual %)"], marker="o",color="b", linestyle="-")
plt.xticks(rotation=90)
plt.title("SOUTH AFRICA")

plt.show()


# # At last, camparision of Malaria incidence rate (per 100,000 people) according to 4 coutries

# In[43]:


plt.figure(figsize = (15,15))

plt.subplot(2,2,1)
plt.plot(df_Zambia["Malaria incidence rate (per 100,000 people)"], marker="^",color="k", linestyle="--")
plt.xticks(rotation=90)
plt.title("ZAMBIA")

plt.subplot(2,2,2)
plt.plot(df_Afghanistan["Malaria incidence rate (per 100,000 people)"], marker="^",color="b", linestyle="--")
plt.xticks(rotation=90)
plt.title("AFGHANISTAN")

plt.subplot(2,2,3)
plt.plot(df_Angola["Malaria incidence rate (per 100,000 people)"], marker="^",color="g", linestyle="--")
plt.xticks(rotation=90)
plt.title("ANGOLA")

plt.subplot(2,2,4)
plt.plot(df_SAF["Malaria incidence rate (per 100,000 people)"], marker="^",color="r", linestyle="--")
plt.xticks(rotation=90)
plt.title("SOUTH AFRICA")

plt.show()


# In[ ]:




